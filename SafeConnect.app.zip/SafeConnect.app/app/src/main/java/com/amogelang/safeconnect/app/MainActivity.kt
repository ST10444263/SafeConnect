package com.amogelang.safeconnect.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.amogelang.safeconnect.app.repository.ApiResult
import com.amogelang.safeconnect.app.repository.AuthRepository
import com.amogelang.safeconnect.app.repository.IncidentRepository
import com.amogelang.safeconnect.app.repository.UserRepository
import com.amogelang.safeconnect.app.util.InputValidator
import com.amogelang.safeconnect.app.util.LocationHelper
import com.amogelang.safeconnect.app.util.SessionManager
import kotlinx.coroutines.launch

// ============================================================
// LoginActivity — launcher activity (set as such in the manifest)
// ============================================================
class LoginActivity : AppCompatActivity() {

    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var tvError: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var sessionManager: SessionManager
    private val authRepository = AuthRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        sessionManager = SessionManager(this)

        // If a valid session is already cached, skip straight to Home.
        if (sessionManager.isLoggedIn()) {
            goToHome()
            return
        }

        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        tvError = findViewById(R.id.tvError)
        progressBar = findViewById(R.id.progressBar)

        findViewById<Button>(R.id.btnLogin).setOnClickListener { attemptLogin() }
        findViewById<TextView>(R.id.tvGoRegister).setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun attemptLogin() {
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString()

        if (!InputValidator.isValidEmail(email)) {
            showError(getString(R.string.error_invalid_email))
            return
        }
        if (!InputValidator.isNotBlank(password)) {
            showError(getString(R.string.error_required_field))
            return
        }

        setLoading(true)
        lifecycleScope.launch {
            when (val result = authRepository.login(email, password)) {
                is ApiResult.Success -> {
                    sessionManager.saveSession(result.data.token, result.data.user)
                    setLoading(false)
                    goToHome()
                }
                is ApiResult.Failure -> {
                    setLoading(false)
                    showError(result.message)
                }
            }
        }
    }

    private fun goToHome() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }

    private fun showError(message: String) {
        tvError.text = message
        tvError.visibility = TextView.VISIBLE
    }

    private fun setLoading(loading: Boolean) {
        progressBar.visibility = if (loading) ProgressBar.VISIBLE else ProgressBar.GONE
        tvError.visibility = if (loading) TextView.GONE else tvError.visibility
        findViewById<Button>(R.id.btnLogin).isEnabled = !loading
    }
}

// ============================================================
// RegisterActivity
// ============================================================
class RegisterActivity : AppCompatActivity() {

    private lateinit var etFullName: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPhone: EditText
    private lateinit var etPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var tvError: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var sessionManager: SessionManager
    private val authRepository = AuthRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        sessionManager = SessionManager(this)

        etFullName = findViewById(R.id.etFullName)
        etEmail = findViewById(R.id.etEmail)
        etPhone = findViewById(R.id.etPhone)
        etPassword = findViewById(R.id.etPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        tvError = findViewById(R.id.tvError)
        progressBar = findViewById(R.id.progressBar)

        findViewById<Button>(R.id.btnRegister).setOnClickListener { attemptRegister() }
        findViewById<TextView>(R.id.tvGoLogin).setOnClickListener { finish() }
    }

    private fun attemptRegister() {
        val fullName = etFullName.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val phone = etPhone.text.toString().trim()
        val password = etPassword.text.toString()
        val confirmPassword = etConfirmPassword.text.toString()

        if (!InputValidator.isNotBlank(fullName)) {
            showError(getString(R.string.error_required_field)); return
        }
        if (!InputValidator.isValidEmail(email)) {
            showError(getString(R.string.error_invalid_email)); return
        }
        if (!InputValidator.isValidPhoneNumber(phone)) {
            showError(getString(R.string.error_required_field)); return
        }
        if (!InputValidator.isStrongPassword(password)) {
            showError(getString(R.string.error_weak_password)); return
        }
        if (!InputValidator.passwordsMatch(password, confirmPassword)) {
            showError(getString(R.string.error_passwords_dont_match)); return
        }

        setLoading(true)
        lifecycleScope.launch {
            // `password` is sent once, over HTTPS in production. The API hashes
            // it with bcrypt before writing anything to the database — see the
            // backend's /auth/register handler. It is never stored in plain
            // text on the device or on the server.
            when (val result = authRepository.register(fullName, email, phone, password)) {
                is ApiResult.Success -> {
                    sessionManager.saveSession(result.data.token, result.data.user)
                    setLoading(false)
                    startActivity(Intent(this@RegisterActivity, HomeActivity::class.java))
                    finishAffinity()
                }
                is ApiResult.Failure -> {
                    setLoading(false)
                    showError(result.message)
                }
            }
        }
    }

    private fun showError(message: String) {
        tvError.text = message
        tvError.visibility = TextView.VISIBLE
    }

    private fun setLoading(loading: Boolean) {
        progressBar.visibility = if (loading) ProgressBar.VISIBLE else ProgressBar.GONE
        findViewById<Button>(R.id.btnRegister).isEnabled = !loading
    }
}

// ============================================================
// HomeActivity
// ============================================================
class HomeActivity : AppCompatActivity() {

    private lateinit var sessionManager: SessionManager
    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar
    private val incidentRepository = IncidentRepository()

    private val locationPermissionRequestCode = 1001

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        sessionManager = SessionManager(this)
        if (!sessionManager.isLoggedIn()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        val user = sessionManager.getUser()
        findViewById<TextView>(R.id.tvGreeting).text = "Hi, ${user?.fullName ?: "there"}"
        findViewById<TextView>(R.id.tvSafetyScore).text =
            "${getString(R.string.label_safety_score)}: ${user?.safetyScore ?: 0}"

        tvStatus = findViewById(R.id.tvStatus)
        progressBar = findViewById(R.id.progressBar)

        findViewById<Button>(R.id.btnSos).setOnClickListener { confirmSos() }
        findViewById<TextView>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun confirmSos() {
        AlertDialog.Builder(this)
            .setTitle(R.string.sos_confirm_title)
            .setMessage(R.string.sos_confirm_message)
            .setPositiveButton("Send") { _, _ -> triggerSos() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun triggerSos() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                locationPermissionRequestCode
            )
            return
        }
        sendIncident()
    }

    private fun sendIncident() {
        progressBar.visibility = ProgressBar.VISIBLE
        tvStatus.text = ""
        lifecycleScope.launch {
            val location = LocationHelper.getCurrentLocation(this@HomeActivity)
            val lat = location?.latitude ?: 0.0
            val lng = location?.longitude ?: 0.0

            when (val result = incidentRepository.reportSos(sessionManager.bearerToken(), lat, lng)) {
                is ApiResult.Success -> {
                    progressBar.visibility = ProgressBar.GONE
                    tvStatus.text = getString(R.string.sos_sent)
                }
                is ApiResult.Failure -> {
                    progressBar.visibility = ProgressBar.GONE
                    tvStatus.text = result.message
                }
            }
        }
    }

    @SuppressLint("SetTextI18n")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == locationPermissionRequestCode &&
            grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            sendIncident()
        } else {
            tvStatus.text = "Location permission is needed to send an accurate SOS."
        }
    }

    @SuppressLint("SetTextI18n")
    override fun onResume() {
        super.onResume()
        // Refresh the displayed safety score in case it changed elsewhere.
        val user = sessionManager.getUser()
        findViewById<TextView>(R.id.tvSafetyScore).text =
            "${getString(R.string.label_safety_score)}: ${user?.safetyScore ?: 0}"
    }
}

// ============================================================
// SettingsActivity
// ============================================================
class SettingsActivity : AppCompatActivity() {

    private lateinit var sessionManager: SessionManager
    private lateinit var spinnerLanguage: Spinner
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private lateinit var switchNotifications: Switch
    private lateinit var tvError: TextView
    private lateinit var progressBar: ProgressBar
    private val userRepository = UserRepository()

    // Codes correspond to what the API expects: en / zu / af / st
    private val languageCodes = listOf("en", "zu", "af", "st")
    private val languageLabels = listOf("English", "isZulu", "Afrikaans", "Sesotho")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        sessionManager = SessionManager(this)
        val user = sessionManager.getUser()

        spinnerLanguage = findViewById(R.id.spinnerLanguage)
        switchNotifications = findViewById(R.id.switchNotifications)
        tvError = findViewById(R.id.tvError)
        progressBar = findViewById(R.id.progressBar)

        spinnerLanguage.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, languageLabels)
        user?.let {
            spinnerLanguage.setSelection(languageCodes.indexOf(it.preferredLanguage).coerceAtLeast(0))
            switchNotifications.isChecked = it.notificationsEnabled
        }

        findViewById<Button>(R.id.btnSave).setOnClickListener { saveSettings() }
        findViewById<Button>(R.id.btnLogout).setOnClickListener { logout() }
    }

    private fun saveSettings() {
        val user = sessionManager.getUser() ?: return
        val selectedLanguage = languageCodes[spinnerLanguage.selectedItemPosition]
        val notificationsEnabled = switchNotifications.isChecked

        progressBar.visibility = ProgressBar.VISIBLE
        tvError.visibility = TextView.GONE

        lifecycleScope.launch {
            when (val result = userRepository.updateSettings(
                user.userId, sessionManager.bearerToken(), selectedLanguage, notificationsEnabled
            )) {
                is ApiResult.Success -> {
                    sessionManager.updateUser(result.data)
                    progressBar.visibility = ProgressBar.GONE
                    Toast.makeText(this@SettingsActivity, "Settings saved", Toast.LENGTH_SHORT).show()
                }
                is ApiResult.Failure -> {
                    progressBar.visibility = ProgressBar.GONE
                    tvError.text = result.message
                    tvError.visibility = TextView.VISIBLE
                }
            }
        }
    }

    private fun logout() {
        sessionManager.clearSession()
        startActivity(Intent(this, LoginActivity::class.java))
        finishAffinity()
    }
}