package com.amogelang.safeconnect.app.network

import com.amogelang.safeconnect.app.model.IncidentRequest
import com.amogelang.safeconnect.app.model.IncidentResponse
import com.amogelang.safeconnect.app.model.LoginRequest
import com.amogelang.safeconnect.app.model.RegisterRequest
import com.amogelang.safeconnect.app.model.UpdateSettingsRequest
import com.amogelang.safeconnect.app.model.UserProfile
import com.amogelang.safeconnect.app.model.AuthResponse
import retrofit2.Response
import retrofit2.http.*

/**
 * Matches the SafeConnect REST API designed in Part 1 (see the Planning &
 * Design document, section 5). Every call returns a Retrofit [Response] so
 * activities can check response.isSuccessful and read response.errorBody()
 * for validation/auth failures rather than only relying on exceptions.
 */
interface ApiService {

    @POST("auth/register")
    suspend fun register(@Body body: RegisterRequest): Response<AuthResponse>

    @POST("auth/login")
    suspend fun login(@Body body: LoginRequest): Response<AuthResponse>

    @PUT("users/{id}")
    suspend fun updateSettings(
        @Path("id") userId: String,
        @Header("Authorization") bearerToken: String,
        @Body body: UpdateSettingsRequest
    ): Response<UserProfile>

    @POST("incidents")
    suspend fun reportIncident(
        @Header("Authorization") bearerToken: String,
        @Body body: IncidentRequest
    ): Response<IncidentResponse>
}
