package com.amogelang.safeconnect.app.util

/**
 * Pure validation logic, deliberately kept free of any Android framework
 * classes so it can be covered by fast JUnit unit tests (see
 * app/src/test/java/com/safeconnect/app/InputValidatorTest.kt) without
 * needing an emulator or instrumented test.
 */
object InputValidator {

    private val EMAIL_REGEX = Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")

    fun isValidEmail(email: String): Boolean {
        if (email.isBlank()) return false
        return EMAIL_REGEX.matches(email.trim())
    }

    /**
     * Requires at least 8 characters, one letter and one digit. This keeps
     * the rule simple enough to explain in the demo video while still
     * rejecting obviously weak passwords like "12345678" or "password".
     */
    fun isStrongPassword(password: String): Boolean {
        if (password.length < 8) return false
        val hasLetter = password.any { it.isLetter() }
        val hasDigit = password.any { it.isDigit() }
        return hasLetter && hasDigit
    }

    fun passwordsMatch(password: String, confirmPassword: String): Boolean {
        return password == confirmPassword
    }

    fun isNotBlank(value: String): Boolean = value.trim().isNotEmpty()

    /** Very light phone-number check: digits, spaces, +, 7-15 chars long. */
    fun isValidPhoneNumber(phone: String): Boolean {
        val cleaned = phone.trim()
        if (cleaned.isEmpty()) return false
        return cleaned.matches(Regex("^\\+?[0-9 ]{7,15}$"))
    }
}
