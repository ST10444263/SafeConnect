package com.amogelang.safeconnect.app.util

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Thin wrapper around the Google Play Services Fused Location Provider SDK
 * (the "connect an app to an appropriate SDK" requirement). Used when the
 * user presses SOS, so the incident report includes real GPS coordinates.
 *
 * Caller is responsible for having already requested and been granted
 * ACCESS_FINE_LOCATION at runtime before calling this.
 */
object LocationHelper {

    @SuppressLint("MissingPermission")
    suspend fun getCurrentLocation(context: Context): Location? {
        val client = LocationServices.getFusedLocationProviderClient(context)
        return suspendCancellableCoroutine { continuation ->
            client.lastLocation
                .addOnSuccessListener { location -> continuation.resume(location) }
                .addOnFailureListener { continuation.resume(null) }
        }
    }
}
