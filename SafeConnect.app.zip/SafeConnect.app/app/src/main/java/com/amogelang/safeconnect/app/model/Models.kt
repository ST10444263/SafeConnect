package com.amogelang.safeconnect.app.model

// ---------- Auth ----------

data class RegisterRequest(
    val fullName: String,
    val email: String,
    val phoneNumber: String,
    val password: String // sent once over HTTPS; the API hashes it before storage, never returns it
)

data class LoginRequest(
    val email: String,
    val password: String
)

data class AuthResponse(
    val token: String,
    val user: UserProfile
)

// ---------- User ----------

data class UserProfile(
    val userId: String,
    val fullName: String,
    val email: String,
    val phoneNumber: String,
    val preferredLanguage: String, // "en" | "zu" | "af" | "st"
    val notificationsEnabled: Boolean,
    val safetyScore: Int
)

data class UpdateSettingsRequest(
    val preferredLanguage: String,
    val notificationsEnabled: Boolean
)

// ---------- Incidents (SOS) ----------

data class IncidentRequest(
    val type: String = "sos",
    val latitude: Double,
    val longitude: Double
)

data class IncidentResponse(
    val incidentId: String,
    val status: String
)

// ---------- Generic error body returned by the API ----------

data class ApiError(
    val message: String
)
