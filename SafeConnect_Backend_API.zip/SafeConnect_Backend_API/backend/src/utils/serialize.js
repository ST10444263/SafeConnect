/**
 * Converts a DB row into the exact JSON shape the Android app's
 * UserProfile model expects (camelCase, booleans as real booleans).
 * Never includes password_hash.
 */
function toUserProfileJson(row) {
  return {
    userId: row.user_id,
    fullName: row.full_name,
    email: row.email,
    phoneNumber: row.phone_number,
    preferredLanguage: row.preferred_language,
    notificationsEnabled: !!row.notifications_enabled,
    safetyScore: row.safety_score,
  };
}

module.exports = { toUserProfileJson };
