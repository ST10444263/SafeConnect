require("dotenv").config();
const express = require("express");
const cors = require("cors");

const authRoutes = require("./routes/auth");
const userRoutes = require("./routes/users");
const incidentRoutes = require("./routes/incidents");

const app = express();

app.use(cors());
app.use(express.json());

// Simple request log — handy when you're narrating the demo video and
// want to show, in a second terminal, exactly what the app is calling.
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} ${req.method} ${req.path}`);
  next();
});

app.get("/", (req, res) => {
  res.json({ status: "ok", service: "SafeConnect API" });
});

app.use("/auth", authRoutes);
app.use("/users", userRoutes);
app.use("/incidents", incidentRoutes);

// Fallback error handler so a bad request never crashes the process
// (matches the "must work with only minor bugs" / robustness requirement).
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: "Something went wrong on the server" });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`SafeConnect API listening on port ${PORT}`);
});
