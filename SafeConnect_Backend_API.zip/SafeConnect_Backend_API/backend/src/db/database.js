const Database = require("better-sqlite3");
const path = require("path");
const { randomUUID } = require("crypto");

// A single SQLite file is enough for this prototype and for the module's
// "connect to a database" requirement. It lives on disk next to the server
// code. For the final PoE, this file can be swapped for a hosted database
// (e.g. Postgres on Render, or Firebase Firestore) without changing the
// route handlers, since all DB access goes through this one module.
const dbPath = path.join(__dirname, "..", "..", "safeconnect.db");
const db = new Database(dbPath);

db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    user_id TEXT PRIMARY KEY,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone_number TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    preferred_language TEXT NOT NULL DEFAULT 'en',
    notifications_enabled INTEGER NOT NULL DEFAULT 1,
    safety_score INTEGER NOT NULL DEFAULT 10,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS incidents (
    incident_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'sos',
    latitude REAL,
    longitude REAL,
    status TEXT NOT NULL DEFAULT 'sent',
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
  );
`);

module.exports = { db, randomUUID };
