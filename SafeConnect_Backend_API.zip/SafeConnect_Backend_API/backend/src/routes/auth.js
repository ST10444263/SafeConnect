const express = require("express");
const bcrypt = require("bcryptjs");
const { db, randomUUID } = require("../db/database");
const { signToken } = require("../middleware/auth");
const { toUserProfileJson } = require("../utils/serialize");

const router = express.Router();

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

router.post("/register", async (req, res) => {
  const { fullName, email, phoneNumber, password } = req.body || {};

  if (!fullName || !email || !phoneNumber || !password) {
    return res.status(400).json({ message: "fullName, email, phoneNumber and password are all required" });
  }
  if (!EMAIL_REGEX.test(email)) {
    return res.status(400).json({ message: "Please provide a valid email address" });
  }
  if (password.length < 8) {
    return res.status(400).json({ message: "Password must be at least 8 characters long" });
  }

  const existing = db.prepare("SELECT user_id FROM users WHERE email = ?").get(email.toLowerCase());
  if (existing) {
    return res.status(409).json({ message: "An account with that email already exists" });
  }

  // The password is hashed with bcrypt (salted, one-way) before it ever
  // touches the database. From this point on, the plain-text password
  // exists only in memory for this one request and is then discarded.
  const passwordHash = await bcrypt.hash(password, 10);

  const userId = randomUUID();
  const createdAt = new Date().toISOString();

  db.prepare(`
    INSERT INTO users (user_id, full_name, email, phone_number, password_hash, preferred_language, notifications_enabled, safety_score, created_at)
    VALUES (?, ?, ?, ?, ?, 'en', 1, 10, ?)
  `).run(userId, fullName, email.toLowerCase(), phoneNumber, passwordHash, createdAt);

  const user = db.prepare("SELECT * FROM users WHERE user_id = ?").get(userId);
  const token = signToken(userId);

  res.status(201).json({ token, user: toUserProfileJson(user) });
});

router.post("/login", async (req, res) => {
  const { email, password } = req.body || {};

  if (!email || !password) {
    return res.status(400).json({ message: "email and password are required" });
  }

  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email.toLowerCase());
  if (!user) {
    return res.status(401).json({ message: "Incorrect email or password" });
  }

  // Compare the submitted password against the stored bcrypt hash — the
  // hash itself is never reversed or decrypted, only compared.
  const passwordMatches = await bcrypt.compare(password, user.password_hash);
  if (!passwordMatches) {
    return res.status(401).json({ message: "Incorrect email or password" });
  }

  const token = signToken(user.user_id);
  res.json({ token, user: toUserProfileJson(user) });
});

module.exports = router;
