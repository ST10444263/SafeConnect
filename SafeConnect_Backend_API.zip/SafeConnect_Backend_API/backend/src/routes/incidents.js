const express = require("express");
const { db, randomUUID } = require("../db/database");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

router.post("/", requireAuth, (req, res) => {
  const { type, latitude, longitude } = req.body || {};

  const incidentId = randomUUID();
  const createdAt = new Date().toISOString();
  const incidentType = type || "sos";

  db.prepare(`
    INSERT INTO incidents (incident_id, user_id, type, latitude, longitude, status, created_at)
    VALUES (?, ?, ?, ?, ?, 'sent', ?)
  `).run(incidentId, req.userId, incidentType, latitude ?? null, longitude ?? null, createdAt);

  // In the full PoE build this is also where a push notification (FCM)
  // and/or a call to an external responder-dispatch API would be
  // triggered. For this prototype we simply persist and acknowledge.
  res.status(201).json({ incidentId, status: "sent" });
});

router.get("/:id", requireAuth, (req, res) => {
  const incident = db.prepare("SELECT * FROM incidents WHERE incident_id = ? AND user_id = ?")
    .get(req.params.id, req.userId);
  if (!incident) return res.status(404).json({ message: "Incident not found" });
  res.json({
    incidentId: incident.incident_id,
    type: incident.type,
    status: incident.status,
    latitude: incident.latitude,
    longitude: incident.longitude,
    createdAt: incident.created_at,
  });
});

module.exports = router;
