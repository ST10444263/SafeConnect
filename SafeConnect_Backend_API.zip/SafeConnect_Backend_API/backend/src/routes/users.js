const express = require("express");
const { db } = require("../db/database");
const { requireAuth } = require("../middleware/auth");
const { toUserProfileJson } = require("../utils/serialize");

const router = express.Router();

const ALLOWED_LANGUAGES = ["en", "zu", "af", "st"];

function ensureSelf(req, res, next) {
  if (req.params.id !== req.userId) {
    return res.status(403).json({ message: "You can only view or edit your own account" });
  }
  next();
}

router.get("/:id", requireAuth, ensureSelf, (req, res) => {
  const user = db.prepare("SELECT * FROM users WHERE user_id = ?").get(req.params.id);
  if (!user) return res.status(404).json({ message: "User not found" });
  res.json(toUserProfileJson(user));
});

router.put("/:id", requireAuth, ensureSelf, (req, res) => {
  const { preferredLanguage, notificationsEnabled } = req.body || {};

  if (preferredLanguage !== undefined && !ALLOWED_LANGUAGES.includes(preferredLanguage)) {
    return res.status(400).json({ message: `preferredLanguage must be one of: ${ALLOWED_LANGUAGES.join(", ")}` });
  }

  const current = db.prepare("SELECT * FROM users WHERE user_id = ?").get(req.params.id);
  if (!current) return res.status(404).json({ message: "User not found" });

  const newLanguage = preferredLanguage !== undefined ? preferredLanguage : current.preferred_language;
  const newNotifications = notificationsEnabled !== undefined ? (notificationsEnabled ? 1 : 0) : current.notifications_enabled;

  db.prepare(`
    UPDATE users SET preferred_language = ?, notifications_enabled = ? WHERE user_id = ?
  `).run(newLanguage, newNotifications, req.params.id);

  const updated = db.prepare("SELECT * FROM users WHERE user_id = ?").get(req.params.id);
  res.json(toUserProfileJson(updated));
});

module.exports = router;
