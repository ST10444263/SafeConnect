# SafeConnect API (Part 2 backend)

A REST API for the SafeConnect Android prototype, built with **Node.js +
Express**, storing data in a real **SQLite database** (via
`better-sqlite3`) and hashing passwords with **bcrypt**. This has been
tested end-to-end (register → login → auth-protected requests → settings
update → incident report) and every endpoint behaves as expected.

## Endpoints

| Method | Path             | Auth? | Purpose |
|--------|------------------|-------|---------|
| GET    | `/`              | No    | Health check |
| POST   | `/auth/register` | No    | Create an account (hashes password with bcrypt) |
| POST   | `/auth/login`    | No    | Log in, returns a JWT session token |
| GET    | `/users/:id`     | Yes   | Get a user's profile/settings |
| PUT    | `/users/:id`     | Yes   | Update `preferredLanguage` / `notificationsEnabled` |
| POST   | `/incidents`     | Yes   | Log an SOS/incident with GPS coordinates |
| GET    | `/incidents/:id` | Yes   | Check an incident's status |

Auth routes use `Authorization: Bearer <token>` — the same token your
Android app already stores via `SessionManager.bearerToken()`.

## Running it locally

```bash
cd backend
npm install
cp .env.example .env     # then edit JWT_SECRET to any long random string
npm start
```

The API listens on `http://localhost:3000`. A file called `safeconnect.db`
appears next to `src/` — that's your real, inspectable SQLite database
(you can open it with the "DB Browser for SQLite" app or the `sqlite3`
CLI to show your lecturer the hashed passwords and stored data).

### Quick manual test

```bash
curl -X POST http://localhost:3000/auth/register \
  -H "Content-Type: application/json" \
  -d '{"fullName":"Thabo Nkosi","email":"thabo@example.com","phoneNumber":"0821234567","password":"Safe1234"}'
```

You should get back a `token` and a `user` object. Use that token as
`Authorization: Bearer <token>` on the protected routes.

## Connecting the Android app to this

- **Emulator, server running on your own laptop:** leave
  `RetrofitClient.BASE_URL` as `http://10.0.2.2:3000/` — the emulator maps
  that address to your computer's localhost.
- **Physical phone, server running on your laptop, same Wi-Fi:** use your
  laptop's local IP instead, e.g. `http://192.168.1.23:3000/`.
- **Hosted (recommended for your demo video, so it's clearly "live"):**
  see below, then update `BASE_URL` to the hosted URL and switch
  `android:usesCleartextTraffic="true"` back to `false` in the manifest
  once it's HTTPS.

## Hosting it (for the demo video and final submission)

**Render (free tier)** is the simplest option:

1. Push this `backend/` folder to a GitHub repo.
2. On [render.com](https://render.com) → New → Web Service → connect the repo.
3. Build command: `npm install`. Start command: `npm start`.
4. Add an environment variable `JWT_SECRET` with a long random value.
5. Deploy — Render gives you a `https://your-service.onrender.com` URL.

One thing worth knowing and mentioning in your voice-over: Render's **free**
web services use an ephemeral filesystem, so the SQLite file can reset on
redeploy or restart. That's fine for demonstrating the prototype, but if
you want data to persist permanently for the final PoE, either:
- add a Render **persistent disk** (small monthly cost), or
- swap SQLite for a hosted database such as Render's free **PostgreSQL**
  or **MongoDB Atlas** free tier — only `src/db/database.js` would need to
  change, since every route talks to the database through that one file.

## Unit/integration testing note

This backend was verified with a full manual request cycle: register →
duplicate register correctly rejected (409) → login with wrong password
correctly rejected (401) → protected route correctly rejected without a
token (401) → protected route succeeds with a valid token → settings
update persists → incident is stored. If your module also wants automated
backend tests (separate from the Android JUnit tests already in the app
project), a `supertest` + `jest` suite can be added on top of this same
Express app on request.
